package sit.int221.validators;

import jakarta.validation.Constraint;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Target({FIELD})
@Retention(RUNTIME)
@Constraint(validatedBy = AnnouncementDisplayValidator.class)
public @interface ValidAnnouncementDisplay {
    String message() default "must be either 'Y' or 'N'";
    Class<?>[] groups() default {};
    Class<?>[] payload() default {};
}
