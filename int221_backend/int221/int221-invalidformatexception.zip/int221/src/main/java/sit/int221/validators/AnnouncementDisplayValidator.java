package sit.int221.validators;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.springframework.stereotype.Component;
import sit.int221.utils.AnnouncementDisplay;

@Component
public class AnnouncementDisplayValidator implements ConstraintValidator<ValidAnnouncementDisplay, Enum<AnnouncementDisplay>> {
    @Override
    public boolean isValid(Enum<AnnouncementDisplay> announcementDisplay, ConstraintValidatorContext constraintValidatorContext) {
        return announcementDisplay.equals(AnnouncementDisplay.Y) || announcementDisplay.equals(AnnouncementDisplay.N);
    }
}