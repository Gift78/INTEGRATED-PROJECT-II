package sit.int221.utils;

public enum AnnouncementDisplay {
    Y, N
}
