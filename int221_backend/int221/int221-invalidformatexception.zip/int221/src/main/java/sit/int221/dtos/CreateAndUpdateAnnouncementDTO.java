package sit.int221.dtos;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import sit.int221.utils.AnnouncementDisplay;
import sit.int221.validators.ValidAnnouncementDisplay;
import sit.int221.validators.ValidCategoryId;

import java.time.ZonedDateTime;
import java.util.Objects;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CreateAndUpdateAnnouncementDTO {
    @NotNull @NotBlank @Size(min = 1, max = 200)
    private String announcementTitle;
    @NotNull @NotBlank @Size(min = 1, max = 10000)
    private String announcementDescription;
    @FutureOrPresent
    private ZonedDateTime publishDate;
    @Future
    private ZonedDateTime closeDate;
    @ValidAnnouncementDisplay
    private AnnouncementDisplay announcementDisplay;
    @NotNull @ValidCategoryId
    private Integer categoryId;

    public void setAnnouncementDisplay(AnnouncementDisplay announcementDisplay) {
        this.announcementDisplay = Objects.requireNonNullElse(announcementDisplay, AnnouncementDisplay.N);
    }
}
