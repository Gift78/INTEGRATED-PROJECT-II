package sit.int221;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Int221Application {

    public static void main(String[] args) {
        SpringApplication.run(Int221Application.class, args);
    }

}
